#!/usr/bin/env python3
"""Standalone Qwen2-VL evaluator for the Khánh 27-09 frozen-context protocol.

Input JSONL: {"qid": "...", "selected_chunk_ids": ["..."]}
There must be exactly one row for each qid in the supplied test manifest.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import re
import string
from collections import Counter, defaultdict
from pathlib import Path
from statistics import fmean
from typing import Any, Iterable

MODEL_ID = "Qwen/Qwen2-VL-7B-Instruct"
MODEL_REVISION = "eed13092ef92e448dd6875b2a00151bd3f7db0ac"
DATASETS = ("hotpotqa", "mmqa", "tatqa", "webqa")
PROMPT_PREFIX = "Answer using only the supplied context. Return only the short answer.\nQuestion: "


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=DATASETS, required=True)
    parser.add_argument("--selection-jsonl", type=Path, required=True)
    parser.add_argument("--method", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--split-root", type=Path, default=Path(__file__).parent / "splits")
    parser.add_argument("--retrieval-root", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument(
        "--webqa-bundle-root",
        type=Path,
        default=Path(os.environ.get("WEBQA_BUNDLE_ROOT", "/dev/shm/uncertainty_rag_webqa_stage_20260922")),
    )
    parser.add_argument("--model", type=Path, default=Path(MODEL_ID))
    parser.add_argument("--model-revision", default=MODEL_REVISION)
    parser.add_argument("--max-new-tokens", type=int, default=24)
    parser.add_argument("--min-pixels", type=int, default=3136)
    parser.add_argument("--max-pixels", type=int, default=200704)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            if line.strip():
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"{path}:{number}: invalid JSON") from exc
                if not isinstance(row, dict):
                    raise ValueError(f"{path}:{number}: expected a JSON object")
                yield row


def plan(path: Path) -> list[str]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value.get("plan"), list):
        raise ValueError(f"{path}: expected a 'plan' list")
    return [str(qid) for qid in value["plan"]]


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_selection(path: Path, test_qids: list[str]) -> dict[str, tuple[str, ...]]:
    expected = set(test_qids)
    output: dict[str, tuple[str, ...]] = {}
    for row in iter_jsonl(path):
        qid = str(row.get("qid", ""))
        ids = row.get("selected_chunk_ids")
        if not qid or qid in output or qid not in expected:
            raise ValueError(f"{path}: invalid, duplicated, or out-of-split qid: {qid!r}")
        if not isinstance(ids, list) or any(not isinstance(value, str) for value in ids):
            raise ValueError(f"{path}: {qid} needs a list of string selected_chunk_ids")
        if len(set(ids)) != len(ids):
            raise ValueError(f"{path}: {qid} repeats a selected chunk id")
        output[qid] = tuple(ids)
    missing = [qid for qid in test_qids if qid not in output]
    if missing:
        raise ValueError(f"{path}: missing {len(missing)} test qids; first: {missing[0]}")
    return output


def frozen_rows(path: Path, qids: list[str]) -> dict[str, list[dict[str, Any]]]:
    wanted = set(qids)
    result: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in iter_jsonl(path):
        qid = str(row.get("qid", ""))
        if qid in wanted:
            result[qid].append(row)
    for qid in qids:
        rows = result.get(qid, [])
        rows.sort(key=lambda row: (int(row["rank"]), str(row["chunk_id"])))
        if not rows or len(rows) > 30 or [int(row["rank"]) for row in rows] != list(range(1, len(rows) + 1)):
            raise ValueError(f"{path}: invalid frozen candidate pool for {qid}")
    return result


def normalize_answer(answer: str) -> str:
    answer = answer.lower()
    answer = re.sub(r"\b(a|an|the)\b", " ", answer)
    answer = answer.translate(str.maketrans("", "", string.punctuation))
    return " ".join(answer.split()).strip()


def exact_match(prediction: str, gold: list[str]) -> float:
    prediction = normalize_answer(prediction)
    return float(any(normalize_answer(answer) == prediction for answer in gold))


def token_f1(prediction: str, gold: list[str]) -> float:
    predicted = normalize_answer(prediction).split()
    if not predicted:
        return 0.0
    best = 0.0
    for answer in gold:
        reference = normalize_answer(answer).split()
        if not reference:
            continue
        overlap = sum((Counter(predicted) & Counter(reference)).values())
        if overlap:
            precision, recall = overlap / len(predicted), overlap / len(reference)
            best = max(best, 2 * precision * recall / (precision + recall))
    return best


def numbers(text: str) -> list[float]:
    output = []
    for item in re.findall(r"-?\d+\.?\d*%?", text):
        try:
            output.append(float(item[:-1]) / 100 if item.endswith("%") else float(item))
        except ValueError:
            pass
    return output


def numerical_accuracy(prediction: str, gold: list[str]) -> float:
    predicted = numbers(prediction)
    if not predicted:
        return exact_match(prediction, gold)
    for answer in gold:
        for left in predicted:
            for right in numbers(answer):
                if abs(left - right) <= 1e-6 or (right and abs((left - right) / right) <= 1e-6):
                    return 1.0
    return 0.0


def keyed(path: Path, key: str) -> dict[str, dict[str, Any]]:
    return {str(row[key]): row for row in iter_jsonl(path)}


def paths(dataset: str, data_root: Path, webqa_root: Path) -> tuple[Path, Path, Path]:
    root = webqa_root if dataset == "webqa" else data_root
    return root / dataset / "questions.jsonl", root / dataset / "corpus.jsonl", root


def image_path(value: str, bundle_root: Path) -> str:
    candidate = Path(value)
    if candidate.is_file() or value.startswith(("http://", "https://", "data:")):
        return value
    resolved = bundle_root / candidate
    if resolved.is_file():
        return str(resolved)
    alternative = bundle_root.parent / "official_bundle_1000_more" / candidate
    if alternative.is_file():
        return str(alternative)
    raise FileNotFoundError(f"Missing image context: {value}")


class QwenGenerator:
    def __init__(self, model: Path, revision: str, min_pixels: int, max_pixels: int) -> None:
        import torch
        from qwen_vl_utils import process_vision_info
        from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

        self.torch = torch
        self.process_vision_info = process_vision_info
        revision_kw = {"revision": revision} if revision else {}
        self.processor = AutoProcessor.from_pretrained(str(model), min_pixels=min_pixels, max_pixels=max_pixels, **revision_kw)
        self.model = Qwen2VLForConditionalGeneration.from_pretrained(
            str(model), torch_dtype=torch.bfloat16, low_cpu_mem_usage=True,
            attn_implementation="sdpa", **revision_kw,
        ).eval().to("cuda")

    def generate(self, prompt: str, context: list[dict[str, str]], max_new_tokens: int) -> str:
        with self.torch.inference_mode():
            content: list[dict[str, str]] = [{"type": "text", "text": prompt + "\n\nContext:\n"}]
            for chunk in context:
                if chunk["modality"] == "image":
                    content.append({"type": "image", "image": chunk["content"]})
                else:
                    content.append({"type": "text", "text": chunk["content"] + "\n"})
            messages = [{"role": "user", "content": content}]
            rendered = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            images, videos = self.process_vision_info(messages)
            inputs = self.processor(text=[rendered], images=images, videos=videos, padding=True, return_tensors="pt").to("cuda")
            generated = self.model.generate(**inputs, do_sample=False, max_new_tokens=max_new_tokens)
            trimmed = [out[len(inp):] for inp, out in zip(inputs.input_ids, generated)]
            return self.processor.batch_decode(trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0].strip()


def write_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def main() -> None:
    args = parse_args()
    calibration = plan(args.split_root / args.dataset / "calibration_manifest.json")
    test = plan(args.split_root / args.dataset / "test_manifest.json")
    if len(calibration) != 1000 or len(test) != 100 or set(calibration) & set(test):
        raise ValueError("Expected disjoint 1,000-calibration / 100-test Khánh split")
    selection = load_selection(args.selection_jsonl, test)
    retrieval = args.retrieval_root / f"{args.dataset}_jina_v4_candidates.jsonl.gz"
    candidates = frozen_rows(retrieval, test)
    contexts: dict[str, list[dict[str, Any]]] = {}
    for qid in test:
        valid = {str(row["chunk_id"]) for row in candidates[qid]}
        unknown = set(selection[qid]) - valid
        if unknown:
            raise ValueError(f"{args.dataset}/{qid}: selected chunk outside frozen pool: {sorted(unknown)[0]}")
        keep = set(selection[qid])
        contexts[qid] = [row for row in candidates[qid] if str(row["chunk_id"]) in keep]

    args.output_dir.mkdir(parents=True, exist_ok=True)
    run = {
        "protocol": "khanh_27_09_qwen2vl_direct_answer_v1", "dataset": args.dataset,
        "method": args.method, "selection_sha256": hash_file(args.selection_jsonl),
        "model": str(args.model), "model_revision": args.model_revision, "decoding": "greedy",
        "max_new_tokens": args.max_new_tokens, "min_pixels": args.min_pixels,
        "max_pixels": args.max_pixels, "calibration_queries": 1000, "test_queries": 100,
    }
    config_path = args.output_dir / "RUN_CONFIG.json"
    if config_path.exists() and json.loads(config_path.read_text()) != run:
        raise ValueError(f"{config_path} differs from this invocation; choose a new output directory")
    if not config_path.exists():
        write_json(config_path, run)
    validation = {"status": "validated", "dataset": args.dataset, "test_queries": 100,
                  "mean_selected_chunks": sum(len(contexts[qid]) for qid in test) / 100,
                  "empty_context_queries": sum(not contexts[qid] for qid in test)}
    if args.dry_run:
        write_json(args.output_dir / "VALIDATION.json", validation)
        print(json.dumps(validation))
        return

    question_path, corpus_path, bundle_root = paths(args.dataset, args.data_root, args.webqa_bundle_root)
    questions, corpus = keyed(question_path, "qid"), keyed(corpus_path, "id")
    missing = [qid for qid in test if qid not in questions]
    if missing:
        raise ValueError(f"question bundle is missing {missing[0]}")
    prediction_path = args.output_dir / "predictions.jsonl"
    completed = {str(row["qid"]): row for row in iter_jsonl(prediction_path)} if prediction_path.exists() else {}
    generator = QwenGenerator(args.model, args.model_revision, args.min_pixels, args.max_pixels)
    with prediction_path.open("a", encoding="utf-8") as handle:
        for index, qid in enumerate(test, 1):
            if qid in completed:
                continue
            context = []
            for row in contexts[qid]:
                source = corpus[str(row["chunk_id"])]
                modality = str(source.get("modality", row.get("modality", "text")))
                content = str(source["content"])
                if modality == "image":
                    content = image_path(content, bundle_root)
                context.append({"id": str(row["chunk_id"]), "content": content, "modality": modality})
            item = questions[qid]
            gold = [str(answer) for answer in item["gold_answers"]]
            prediction = generator.generate(PROMPT_PREFIX + str(item["question"]), context, args.max_new_tokens)
            record = {"qid": qid, "gold_answers": gold, "prediction": prediction,
                      "metrics": {"em": exact_match(prediction, gold), "f1": token_f1(prediction, gold), "numerical_accuracy": numerical_accuracy(prediction, gold)},
                      "context": {"n_chunks": len(context), "chunk_ids": [chunk["id"] for chunk in context]}}
            handle.write(json.dumps(record, ensure_ascii=False) + "\n"); handle.flush()
            completed[qid] = record
            print(f"[{args.dataset} {index}/100] {qid}", flush=True)
    records = [completed[qid] for qid in test]
    summary = {**validation, "status": "complete", "metrics": {metric: fmean(float(row["metrics"][metric]) for row in records) for metric in ("em", "f1", "numerical_accuracy")}}
    write_json(args.output_dir / "SUMMARY.json", summary)
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
