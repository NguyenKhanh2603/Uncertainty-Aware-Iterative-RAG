# Standalone Khánh 27-09 downstream evaluator

This archive evaluates an externally selected context using the fixed Khánh 27-09 protocol. It has no imports from the project repository. The archive includes all four calibration/test qid manifests and the evaluator itself.

The input method supplies one JSONL row per one of the 100 held-out test qids:

```json
{"qid":"...","selected_chunk_ids":["chunk-id-a","chunk-id-b"]}
```

The evaluator checks that all 100 qids are present and every chunk ID belongs to that query's frozen Jina candidate pool. It always orders retained chunks by frozen retrieval rank. The fixed generator is Qwen2-VL-7B-Instruct at revision `eed13092ef92e448dd6875b2a00151bd3f7db0ac`, with greedy decoding, 24 new tokens, `min_pixels=3136`, and `max_pixels=200704`.

## Required external inputs

The archive intentionally excludes large data and model files. Supply:

- `--retrieval-root`: directory containing `{dataset}_jina_v4_candidates.jsonl.gz` from the frozen Jina-v4 logs.
- `--data-root`: the extracted HotpotQA/MMQA/TAT-QA bundle, containing `<dataset>/questions.jsonl` and `<dataset>/corpus.jsonl`.
- `--webqa-bundle-root`: equivalent WebQA bundle when evaluating WebQA.
- a CUDA-enabled Python environment with the packages in `requirements.txt`, and access to the pinned Qwen checkpoint.

Validate an external selection without loading Qwen:

```bash
python evaluate_selection.py \
  --dataset hotpotqa \
  --selection-jsonl /path/my_method_hotpotqa.jsonl \
  --method my_method \
  --retrieval-root /path/zip_calibration_split_20_09/retrieval \
  --data-root /path/data/zip_calibration_split_20_09 \
  --output-dir /path/results/my_method/hotpotqa \
  --dry-run
```

Remove `--dry-run` to generate answers. The output directory is resumable and records `RUN_CONFIG.json`, `predictions.jsonl`, and `SUMMARY.json`.

See `PROTOCOL.json` for the exact machine-readable protocol.
